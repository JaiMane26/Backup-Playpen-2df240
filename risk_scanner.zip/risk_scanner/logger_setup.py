"""Configures and sets up loggers for risk-scanner."""

import logging


def setup_logger(name=__name__):
    """To set up a logger with a StreamHandler and a basic Formatter.

    Args:
        name (str, optional): The name of the logger. Defaults to __name__.

    Returns:
        logging.Logger: The configured logger instance.

    """
    logger = logging.getLogger(name)
    if not logger.handlers:
        handler = logging.StreamHandler()
        formatter = logging.Formatter(
            "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
        )
        handler.setFormatter(formatter)
        logger.addHandler(handler)
        logger.setLevel(logging.INFO)
    return logger
