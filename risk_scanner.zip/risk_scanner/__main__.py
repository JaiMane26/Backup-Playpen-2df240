"""script entry point."""

import io
import sys

from risk_scanner import cli


def main():  # noqa: D103
    cli.main(sys.argv[1:])


if __name__ == "__main__":
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")
    main()
