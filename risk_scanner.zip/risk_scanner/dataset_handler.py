"""Handles loading, preprocessing, and managing datasets for risk-scanner."""
