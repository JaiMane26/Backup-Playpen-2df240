"""Risk report handling."""


class ReportGenerator:
    """Generates and manages risk evaluation reports for risk scanning outputs."""

    def __init__(self, model):
        self.model = model

    def generate_report(self, eval_ourcome):
        report_lines = [
            f"# Risk Evaluation Report for {self.model.model_name}",
            f"## Model Type: {self.model.model_type}",
            "## Risks Scanned:",
            "### Risk",
            f"{eval_ourcome}",
        ]
        return "\n".join(report_lines)

    def save_report(self):
        # filename="risk_scan_report.md"):
        # with open(filename, "w") as file:
        #     file.write(report)
        # print(f"Report saved to {filename}")
        return
