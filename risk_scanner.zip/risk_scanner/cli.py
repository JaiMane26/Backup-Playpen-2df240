"""CLI entry point."""

import argparse

from risk_scanner.logger_setup import setup_logger
from risk_scanner.model_integration import MODEL_TYPES, get_model
from risk_scanner.report_generator import ReportGenerator
from risk_scanner.scanner import RISK_STRATEGIES, RiskScanner

# Configure system-level logger
logger = setup_logger()


def parse_args(args=None):
    """Parse the command line arguments."""
    parser = argparse.ArgumentParser(
        description="Process risk-scanner command line arguments."
    )
    parser.add_argument(
        "-t",
        "--model-type",
        type=str,
        required=True,
        choices=MODEL_TYPES,
        help="Type of the model, such as 'openai', or 'vertexai'",
    )
    parser.add_argument(
        "-m",
        "--model-name",
        type=str,
        required=True,
        help="Name of the model, such as gemini-1.5-pro-002",
    )
    parser.add_argument(
        "-r",
        "--risks",
        type=str,
        required=False,
        choices=list(RISK_STRATEGIES.keys()),
        nargs="*",
        help="Risks to be scanned for",
    )

    return parser.parse_args(args)


def main(arguments=None) -> None:
    """CLI main entry point for risk scanning tool.

    1. parse the arguments
    2. configure the model
    3. run the risk scan
    4. generate report
    """
    args = parse_args(arguments)
    logger.info(f"Model Type: {args.model_type}")
    logger.info(f"Model Name: {args.model_name}")
    logger.info(f"Risks: {args.risks}")

    model = get_model(args.model_type, args.model_name)
    report_generator = ReportGenerator(model)

    risks = args.risks if args.risks else RISK_STRATEGIES.keys()
    scanner = RiskScanner(model, report_generator, risks)
    scanner.handle_risks()

    print("happy risk-free scanning :-)")
