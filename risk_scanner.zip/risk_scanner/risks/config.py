"""To handle Config variables."""

bias_config = {
    'RISK_RAW_DATA_FILE': 'bias_raw_data_bbq_110.csv',
    'DATA_DIR': 'data',
    'TEMPERATURE_RISK': 0.2,
    'PERSIST_FILE': False,
    'LOGGING_LEVEL': 'INFO',
    'temperature': None,
    'top_p': None,
    'top_k': None,
    'candidate_count': None,
    'max_output_tokens': None,
    'stop_sequences': None
}

hallucination_config={
    'RISK_RAW_DATA_FILE': 'bias_raw_data_bbq_110.csv',
    'DATA_DIR': 'data',
    'TEMPERATURE_RISK': 0.2,
    'PERSIST_FILE': False,
    'LOGGING_LEVEL': 'INFO',
    'temperature': None,
    'top_p': None,
    'top_k': None,
    'candidate_count': None,
    'max_output_tokens': None,
    'stop_sequences': None
}

