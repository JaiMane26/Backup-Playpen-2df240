"""Exposure and evaluate of all risks."""

from abc import ABC, abstractmethod

import pandas as pd

from risk_scanner.logger_setup import setup_logger

# Set up the logger for this module
logger = setup_logger(__name__)


class Risk(ABC):
    """Base class for all risk handlers."""

    def __init__(self) -> None:
        super().__init__()
        self._model = None
        self._adjudicator = None

        self.dataset = None

    @property
    def model(self):
        return self._model

    @model.setter
    def model(self, model):
        self._model = model

    @property
    def adjudicator(self):
        return self._adjudicator

    @adjudicator.setter
    def adjudicator(self, adjudicator):
        self._adjudicator = adjudicator

    @abstractmethod
    def load_dataset(self):
        pass

    @abstractmethod
    def expose_risk(self) -> pd.DataFrame:
        pass

    @abstractmethod
    def evaluate_risk(self, eval_df: pd.DataFrame):
        pass

    def scan(self):
        self.load_dataset()
        eval_df = self.expose_risk()
        eval_outcome = self.evaluate_risk(eval_df)

        return eval_outcome
