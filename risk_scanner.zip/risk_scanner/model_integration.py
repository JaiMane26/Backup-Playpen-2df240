"""Model class for handling model-related tasks."""

from abc import ABC, abstractmethod

import vertexai
from google.auth import default
from vertexai.generative_models import (
    GenerationConfig,
    GenerativeModel,
)

from risk_scanner.logger_setup import setup_logger

# Set up the logger for this module
logger = setup_logger(__name__)

MODEL_TYPES = ["openai", "vertexai"]


def get_gcp_project_id():
    """To get the GCP Project ID."""
    credentials, project_id = default()
    if not project_id:
        raise Exception(
            "Could not determine GCP Project ID. Check your authentication."
        )
    return project_id


def get_model(model_type, model_name, **kwargs):
    """To get a solid LLM wrapper through model factory."""
    if model_type == "vertexai":
        model = VertexAI_LLM(model_name)
    elif model_type == "openai":
        model = OpenAI_LLM(model_name)
    else:
        raise ValueError(f"Unknown model type: {model_type}")

    model.configure(**kwargs)

    return model


def check_model_connection(model):
    """To send a simple prompt to test the connection."""
    response = model.generate(
        "Hello."
    )  # "Hello! 👋 \n\nHow can I help you today? 😊 \n"

    return False if response == "No response" else True


class BaseLLM(ABC):
    """Base for all LLM wrappers."""

    def __init__(self, model_name):  # noqa: D107
        self.model_type = None
        self.model_name = model_name
        self.llm = None

    @abstractmethod
    def configure(self):
        """To config the LLM wrapper."""
        pass

    @abstractmethod
    def generate(self):
        """To generates text based on a given prompt."""
        pass

    # @abstractmethod
    # def get_details(self):
    #     """Return details about the model being used."""
    #     pass


class VertexAI_LLM(BaseLLM):
    """Model wrapper for VertexAI's Gemini models.

    Ref: https://cloud.google.com/vertex-ai/generative-ai/docs/model-reference/inference
    """

    def __init__(self, model_name):  # noqa: D107
        self.model_type = "vertexai"
        self.model_name = model_name
        self.llm = None

        self.project_id = get_gcp_project_id()

        # ToDo: how to get project location better?

        vertexai.init(project=self.project_id, location="europe-west2")
        logger.info(f"Setting model to {self.model_type}: {self.model_name}")

    def configure(self, **kwargs):
        """To config the VertexAI GenerativeModel.

        All the parameters used by the GenerationConfig should be passed through kwargs.
        """
        self.api_key = kwargs.get("api_key", None)
        #        self.project_location = kwargs.get("location", "europe-west2")

        self.temperature = kwargs.get("temperature", 1)

        config = GenerationConfig(
            temperature=self.temperature,
            top_p=None,
            top_k=None,
            candidate_count=None,
            max_output_tokens=None,
            stop_sequences=None,
        )
        self.llm = GenerativeModel(self.model_name, generation_config=config)

    def generate(self, prompt):
        """To generate response through LLM APIs.

        ref: https://cloud.google.com/vertex-ai/generative-ai/docs/reference/python/latest/vertexai.generative_models.GenerativeModel
        """
        try:
            generated_answer = self.llm.generate_content(prompt).text
        except Exception as ex:
            generated_answer = "No response"
            logger.info(f"No response from model with exception: {ex}")

        return generated_answer


# import openai
class OpenAI_LLM(BaseLLM):
    """Model wrapper for using OpenAI style APIs.

    Ref: https://cloud.google.com/vertex-ai/generative-ai/docs/multimodal/call-vertex-using-openai-library
    """

    def __init__(self, model_name):  # noqa: D107
        self.model_type = "openai"
        self.model_name = model_name
        self.project_id = get_gcp_project_id()

        vertexai.init(project=self.project_id, location="europe-west2")
        logger.info(f"Setting model to {self.model_type}: {self.model_name}")

    # ToDos
    def configure(self, **kwargs):
        """To config the OpenAI APIs.

        All the parameters used should be passed through kwargs.
        """
        self.api_key = kwargs.get("api_key", None)
        self.project_location = kwargs.get("location", "europe-west2")

        self.temperature = kwargs.get("temperature", 1)

        # To config and initiate the api
        self.llm = None

    # ToDos
    def generate(self, prompt):
        """To generate response through LLM APIs."""
        # response = openai.ChatCompletion.create(
        #     model=self.model_name,
        #     messages=[{"role": "user", "content": prompt}]
        # )
        # return response.choices[0].message["content"]

        generated_answer = "what ever"

        return generated_answer
