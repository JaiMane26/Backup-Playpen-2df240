"""Top-level package for risk-scanner."""

__version__ = "0.0.1"
__app__ = "risk-scanner"
__description__ = "LLM risk scanner"
