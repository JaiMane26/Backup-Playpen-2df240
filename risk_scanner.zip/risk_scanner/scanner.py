"""Handling risk scanning."""

from risk_scanner.logger_setup import setup_logger
from risk_scanner.risks.bias import Bias
from risk_scanner.risks.hallucination import Hallucination
from risk_scanner.risks.misalignment import Misalignment
from risk_scanner.risks.misinformation import Misinformation

logger = setup_logger(__name__)

RISK_STRATEGIES = {
    "bias": Bias,
    "misinformation": Misinformation,
    "misalignment": Misalignment,
    "hallucination": Hallucination,
    # "toxicity": Toxicity
    # "privacy": Privacy
    # "ip_copyright": IP_copyright
    # "attacks": Attacks
    # "economic_crime": Economic_crime
    # "environment": Environment
}


class RiskScanner:
    """Context class for handling risks."""

    def __init__(self, model, report_generator, risks):
        self.model = model
        self.risks = risks
        self.report_generator = report_generator

    @staticmethod
    def get_risk_handler(risk):
        risk_handler = RISK_STRATEGIES.get(risk, None)
        return risk_handler()

    def handle_risks(self):
        for risk in self.risks:
            risk_handler = self.get_risk_handler(risk)
            risk_handler.model = self.model
            eval_outcome = risk_handler.scan()
            self.report_generator.generate_report(eval_outcome)

        self.report_generator.save_report()
