"""To provide pytest fixtures."""

from unittest.mock import patch

import pytest

from risk_scanner.model_integration import OpenAI_LLM, VertexAI_LLM
from risk_scanner.risks.bias import Bias
from risk_scanner.risks.hallucination import Hallucination
from risk_scanner.risks.misalignment import Misalignment
from risk_scanner.risks.misinformation import Misinformation


@pytest.fixture
def bias_risk():
    return Bias()


@pytest.fixture
def hallucination_risk():
    return Hallucination()


@pytest.fixture
def misalignment_risk():
    return Misalignment()


@pytest.fixture
def misinformation_risk():
    return Misinformation()


@pytest.fixture
def vertexai_model():
    with (
        patch(
            "risk_scanner.model_integration.get_gcp_project_id", return_value="12345"
        ),
        patch("vertexai.init"),
    ):
        yield VertexAI_LLM("any_gemini_mode_name")


@pytest.fixture
def openai_model():
    return OpenAI_LLM("any_gemini_mode_name")
