"""To test the cli module."""

from argparse import Namespace

import pytest

from risk_scanner.cli import main, parse_args
from risk_scanner.model_integration import BaseLLM


# risk-scanner --model-type vertexai --model-name target_model_name
def test_parse_args_model_without_risks():
    args = parse_args(["--model-type", "openai", "--model-name", "target_model_name"])
    assert args.model_type == "openai"
    assert args.model_name == "target_model_name"
    assert args.risks is None


@pytest.mark.parametrize(
    "input_args, expected",
    [
        (
            ["--model-type", "openai", "--model-name", "gpt-3.5-turbo"],
            {"model_type": "openai", "model_name": "gpt-3.5-turbo", "risks": None},
        ),
        (
            [
                "--model-type",
                "vertexai",
                "--model-name",
                "gemini-1.5-pro-001",
                "--risks",
                "bias",
            ],
            {
                "model_type": "vertexai",
                "model_name": "gemini-1.5-pro-001",
                "risks": ["bias"],
            },
        ),
        (
            [
                "-t",
                "vertexai",
                "-m",
                "gemini-1.5-pro-002",
                "-r",
                "misalignment",
                "bias",
            ],
            {
                "model_type": "vertexai",
                "model_name": "gemini-1.5-pro-002",
                "risks": ["misalignment", "bias"],
            },
        ),
    ],
    ids=["model_without_risks", "model_with_single_risk", "model_with_multiple_risks"],
)
def test_parse_args_valid(input_args, expected):
    """To test the cli usages defined above.

    risk-scanner --model-type openai --model-name gpt-3.5-turbo
    risk-scanner --model-type vertexai --model-name gemini-1.5-pro-001 --risks bias
    risk-scanner -t vertexai -m gemini-1.5-pro-002 -r misalignment bias
    """
    args = parse_args(input_args)
    assert args.model_type == expected["model_type"]
    assert args.model_name == expected["model_name"]
    assert args.risks == expected["risks"]


@pytest.mark.parametrize(
    "input_args",
    [
        (["--model-name", "gpt-3.5-turbo", "--risks", "bias"]),
        (["--model-type", "openai", "--risks", "bias"]),
        (
            [
                "--model_type",
                "openai",
                "--model_name",
                "gpt-3.5-turbo",
                "--risks",
                "invalid-risk",
            ]
        ),
    ],
    ids=["missing_model_type", "missing_model_name", "unknown_risk"],
)
def test_parse_args_invalid(input_args):
    """To test the cli usages defined below.

    risk-scanner --model-name gpt-3.5-turbo --risks bias
    risk-scanner --model-type openai --risks bias
    risk-scanner -t" vertexai -m gemini-1.5-pro-002 -r misalignment bias
    """
    with pytest.raises(SystemExit):
        parse_args(input_args)


def test_main(mocker, caplog):
    """To test the main functions."""
    mock_parse_args = mocker.patch(
        "risk_scanner.cli.parse_args",
        return_value=Namespace(
            model_type="vertexai", model_name="any_model", risks="bias"
        ),
    )
    mock_get_model = mocker.patch("risk_scanner.cli.get_model", return_value=BaseLLM)
    MockReportGenerator = mocker.patch("risk_scanner.cli.ReportGenerator")
    MockRiskScanner = mocker.patch("risk_scanner.cli.RiskScanner")

    with caplog.at_level("INFO"):
        main()

    mock_parse_args.assert_called_once()
    mock_get_model.assert_called_once()
    MockReportGenerator.assert_called_once()
    MockRiskScanner().handle_risks.assert_called_once()

    assert "Model Type: vertexai" in caplog.text
    assert "Model Name: any_model" in caplog.text
