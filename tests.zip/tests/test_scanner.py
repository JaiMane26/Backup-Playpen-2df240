"""Unit tests for the scanner module."""
