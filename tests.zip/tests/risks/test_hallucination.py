"""To test the hallucination risk."""

import pandas as pd
import pytest
from pandas.testing import assert_frame_equal
from rouge_score import rouge_scorer

from risk_scanner.risks.hallucination import calculate_rouge_score

scorer = rouge_scorer.RougeScorer(["rougeL"], use_stemmer=True)


@pytest.mark.parametrize(
    "generated_answer, correct_answers, incorrect_answers, expected_score",
    [
        (
            "This is a generated answer.",
            [
                "This is a correct answer.",  # RougeL: 4/5 (max)
                "This is another correct answer.",  #   3/5
            ],
            ["This is an incorrect answer."],  # RougeL: 3/5 (max)
            0.2,
        ),
        (
            "This is another generated answer.",
            ["This is another correct answer."],  # RoughL: 4/5 (max)
            [
                "This is an incorrect answer.",  # 3/5
                "This is another incorrect answer.",  #  4/5(max)
            ],
            0,
        ),
    ],
)
def test_calculate_rouge_score(
    generated_answer, correct_answers, incorrect_answers, expected_score
):
    """Test if the ROUGE score is calculated correctly."""
    score = calculate_rouge_score(generated_answer, correct_answers, incorrect_answers)
    assert score == pytest.approx(expected_score)


def test_hallucination_load_dataset(caplog, hallucination_risk):
    with caplog.at_level("INFO"):
        hallucination_risk.load_dataset()
    assert "Handling Hallucination risk's dataset..." in caplog.text


def test_hallucination_evaluate_risk(caplog, hallucination_risk):
    with caplog.at_level("INFO"):
        hallucination_risk.evaluate_risk()
    assert "Evaluating Hallucination risk..." in caplog.text


@pytest.mark.parametrize(
    "hallucination_df, expected_score_df",
    [
        (
            pd.DataFrame(
                {
                    "question": ["What should I ask?", "question 1?", "question 2?"],
                    "best_answer": [
                        "It's up to you.",
                        "What question?",
                        "What question?",
                    ],
                    "correct_answers": [
                        ["What ever you want", "I don't know"],
                        ["a", "b"],
                        ["c", "d"],
                    ],
                    "incorrect_answers": [
                        ["who cares", "kiss kiss"],
                        ["a", "b"],
                        ["c", "d"],
                    ],
                }
            ),
            pd.DataFrame(
                {
                    "question": ["What should I ask?", "question 1?", "question 2?"],
                    "generated_answer": ["Hello! How can I help you today?"] * 3,
                    "score": [0.181818, 0, 0],
                }
            ),
        ),
    ],
)
def test_hallucination_expose_risk(
    mocker,
    vertexai_model,
    hallucination_risk,
    hallucination_df,
    expected_score_df,
):
    mocker.patch.object(
        vertexai_model, "generate", return_value="Hello! How can I help you today?"
    )
    mocker.patch.object(vertexai_model, "configure")

    hallucination_risk.model = vertexai_model
    hallucination_risk.dataset = hallucination_df
    # mocker.patch.object(
    #     hallucination_risk, "load_dataset", return_value=hallucination_df
    # )

    score_df = hallucination_risk.expose_risk()

    assert_frame_equal(score_df, expected_score_df)
