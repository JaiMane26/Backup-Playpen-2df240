"""To test the bias risk."""

from unittest.mock import MagicMock

import numpy as np
import pandas as pd
import pytest

from risk_scanner.risks.bias import Bias


@pytest.fixture
def bias_instance():
    """Fixture to create an instance of the Bias class."""
    return Bias()


@pytest.fixture
def sample_data():
    """Fixture to provide sample data for testing."""
    data = {
        "context": ["Context 1", "Context 2", "Context 3"],
        "question": ["Question 1", "Question 2", "Question 3"],
        "ans0": ["Answer 0", "Answer 0", "Answer 0"],
        "ans1": ["Answer 1", "Answer 1", "Answer 1"],
        "ans2": ["Answer 2", "Answer 2", "Answer 2"],
        "label": [0, 1, 2],
        "category": ["Category 1", "Category 2", "Category 1"],
    }
    return pd.DataFrame(data)


def test_load_dataset(bias_instance, sample_data, monkeypatch):
    """To test the load_dataset method of the Bias class."""
    # Mock the pd.read_csv function to return our sample data
    monkeypatch.setattr(pd, "read_csv", lambda *args, **kwargs: sample_data)

    # Call the load_dataset method
    bias_instance.load_dataset()

    # Assert that the dataset attribute is set correctly
    pd.testing.assert_frame_equal(bias_instance.dataset, sample_data)


def test_expose_risk(bias_instance, sample_data):
    """To test the expose_risk method of the Bias class."""
    # Mock the model and its generate method
    mock_model = MagicMock()
    mock_model.generate.side_effect = ["Answer 0", "Answer 1", "Wrong Answer"]
    bias_instance.model = mock_model

    # Set the dataset for the test
    bias_instance.dataset = sample_data.copy()

    # Call the expose_risk method
    result_df = bias_instance.expose_risk()

    # Assert that the 'response' column in the DataFrame contains the expected values
    assert list(result_df["response"]) == ["Answer 0", "Answer 1", "Wrong Answer"]


def test_evaluate_risk(bias_instance, sample_data, caplog):
    """To test the evaluate_risk method of the Bias class."""
    # Mock the model
    mock_model = MagicMock()
    mock_model.generate.side_effect = ["Answer 0", "Answer 1", "Wrong Answer"]
    bias_instance.model = mock_model

    # Set the dataset for the test
    bias_instance.dataset = sample_data.copy()

    # Call expose_risk to populate the 'response' column
    bias_instance.expose_risk()

    # Call the evaluate_risk method
    with caplog.at_level("INFO"):
        bias_instance.evaluate_risk(bias_instance.dataset)

    # Assertions for evaluate_risk
    expected_response_labels = [0, 1, np.nan]
    expected_match_values = [True, True, False]

    assert np.allclose(
        bias_instance.dataset["response_label"],
        expected_response_labels,
        equal_nan=True,
    )
    assert list(bias_instance.dataset["match"]) == expected_match_values

    # Check log messages
    assert "Evaluating Bias risk..." in caplog.text
    assert "Proportion of null responses: 0.00%" in caplog.text
    assert "Overall bias rate: 0.333" in caplog.text
    assert "breakdown bias rate:" in caplog.text
