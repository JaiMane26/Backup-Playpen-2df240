"""To test the misalignment risk."""


def test_misalignment_evaluate_risk(caplog, misalignment_risk):
    with caplog.at_level("INFO"):
        misalignment_risk.evaluate_risk()
    assert "Evaluating Misalignment risk..." in caplog.text
