"""Unit tests for the test_logger module."""
