"""Unit test for the model_integration module."""

import pytest
from vertexai.generative_models import (
    GenerativeModel,
)

from risk_scanner.model_integration import (
    OpenAI_LLM,
    VertexAI_LLM,
    check_model_connection,
    get_model,
)


@pytest.mark.parametrize(
    "model_type, model_name, config, expected_class",
    [
        (
            "openai",
            "gpt-3.5-turbo",
            {"fake_api_key": "a fake key", "item": "something"},
            OpenAI_LLM,
        ),
        (
            "vertexai",
            "gemini_pro_1.5_001",
            {
                "api_key": "12345678",
                "model_endpoint": "projects/123/locations/us-central1/endpoints/67890",
                "project": "fake_project",
            },
            VertexAI_LLM,
        ),
    ],
    ids=["openai_factory", "vertexai_factory"],
)
def test_get_model(mocker, model_type, model_name, config, expected_class):
    if model_type == "vertexai":
        mock_configuration = mocker.patch(
            "risk_scanner.model_integration.VertexAI_LLM.configure"
        )
    else:
        mock_configuration = mocker.patch(
            "risk_scanner.model_integration.OpenAI_LLM.configure"
        )
    mocker.patch(
        "risk_scanner.model_integration.get_gcp_project_id", return_value="12345"
    )
    mock_vertexai = mocker.patch("vertexai.init")

    model = get_model(model_type, model_name, **config)

    assert isinstance(model, expected_class)
    assert model.model_name == model_name
    assert model.model_type == model_type
    assert model.project_id == "12345"
    mock_vertexai.assert_called_once()
    mock_configuration.assert_called_once()


@pytest.mark.parametrize(
    "model_type, model_name, config",
    [
        ("unknown", "unknown", {"api_key": "12345678", "item": "something"}),
    ],
    ids=["unknown_model_factory"],
)
def test_get_model_invalid(model_type, model_name, config):
    with pytest.raises(ValueError):
        get_model(model_type, model_name, **config)


@pytest.mark.parametrize(
    "response, expectation",
    [
        ("Hello! 👋 \n\nHow can I help you today? 😊 \n", True),
        ("No response", False),
    ],
)
def test_check_model_connection(mocker, vertexai_model, response, expectation):
    mocker.patch.object(vertexai_model, "generate", return_value=response)

    assert check_model_connection(vertexai_model) == expectation


def test_vertexai_llm_configure(mocker, vertexai_model):
    mocker.patch(
        "risk_scanner.model_integration.get_gcp_project_id", return_value="12345"
    )
    vertexai_model.configure()

    assert vertexai_model.project_id == "12345"

    mock_llm = mocker.MagicMock(spec=GenerativeModel)
    vertexai_model.llm = mock_llm

    assert isinstance(vertexai_model.llm, GenerativeModel)


def test_vertexai_llm_generate(mocker, vertexai_model):
    mock_llm = mocker.MagicMock()
    mock_llm.generate_content.return_value = {
        "text": "Hello! 👋 \n\nHow can I help you today? 😊 \n"
    }
    mocker.patch.object(vertexai_model, "llm", return_value=mock_llm)

    response = vertexai_model.generate("Hello.")
    assert response.startswith("Hello")
