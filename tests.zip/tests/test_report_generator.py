"""Unit tests for the report_generator module."""
